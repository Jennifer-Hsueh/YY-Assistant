import { useEffect, useState } from 'react';
import { usePlan } from '../context/PlanContext';
import { ReadOnlyNotice } from '../components/PlanNotice';
import { Link } from 'react-router-dom';
import { api } from '../lib/api';
import { useLanguage } from '../context/LanguageContext';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Card, CardContent } from '../components/ui/card';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '../components/ui/select';
import LedgerSubNav from '../components/LedgerSubNav';
import Categories from './Categories';
import { useIsDesktop, DESKTOP_QUERY } from '../lib/useIsDesktop';
import MonthSwitcher from '../components/MonthSwitcher';

function todayLocal() {
  const d = new Date();
  const offset = d.getTimezoneOffset();
  return new Date(d.getTime() - offset * 60000).toISOString().slice(0, 10);
}

function toLocalDateInput(isoString) {
  const d = new Date(isoString);
  const offset = d.getTimezoneOffset();
  return new Date(d.getTime() - offset * 60000).toISOString().slice(0, 10);
}

const emptyForm = { type: 'expense', amount: '', category: '', note: '', account_id: '', occurred_at: todayLocal() };
const emptyTransfer = { from: '', to: '', amount: '', exchangeRate: '' };
// 功能列(分段按鈕)統一樣式:紙色底框 + 選中項目用 muted 底
const SEG_BAR = 'flex rounded-lg border border-border bg-card p-1 text-sm shadow-sm';
const segBtn = (on) => `rounded-md transition-colors ${on ? 'bg-muted font-medium' : 'text-muted-foreground'}`;

const emptyFilters = { from: '', to: '', type: 'all', account: '', category: '', min: '', max: '', keyword: '' };

export default function Transactions() {
  const { t } = useLanguage();
  const [view, setView] = useState('list');
  const [transactions, setTransactions] = useState([]);
  const [accounts, setAccounts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState(emptyForm);

  // 桌機版預設「新增」;手機版一進來不選任何功能,直接顯示帳務資料
  const [actionMode, setActionMode] = useState(() => (window.matchMedia(DESKTOP_QUERY).matches ? 'add' : null));
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [month, setMonth] = useState(() => { const n = new Date(); return new Date(n.getFullYear(), n.getMonth(), 1); });
  const [activeId, setActiveId] = useState(null);

  const [transfer, setTransfer] = useState(emptyTransfer);
  const [transferError, setTransferError] = useState('');
  const [rates, setRates] = useState({ TWD: 1 });
  // 桌機版左側顯示內容:記帳明細 / 查詢 / 管理分類
  const [panel, setPanel] = useState('list');
  const isDesktop = useIsDesktop();
  const { can } = usePlan();
  const canLedger = can('ledger');
  // 日曆檢視:點選的日期(下方列出當天紀錄,可直接點選編輯/刪除)
  const [selectedDay, setSelectedDay] = useState(null);

  async function load() {
    setLoading(true);
    try {
      const [{ transactions }, { accounts }, { categories }] = await Promise.all([
        api.listTransactions(),
        api.listAccounts(),
        api.listCategories(),
      ]);
      setTransactions(transactions);
      setAccounts(accounts);
      setCategories(categories.filter((c) => c.type !== 'event'));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, []);
  useEffect(() => {
    const onChanged = () => load();
    window.addEventListener('yy:data-changed', onChanged);
    return () => window.removeEventListener('yy:data-changed', onChanged);
  }, []);

  async function reloadCategories() {
    try {
      const { categories } = await api.listCategories();
      setCategories(categories.filter((c) => c.type !== 'event'));
    } catch (err) {
      console.error(err);
    }
  }

  // 新增/編輯/轉帳/查詢/管理分類 五選一(手機、網頁相同);再點一次已選的項目 = 回到只看帳務資料
  function selectMobile(key) {
    const isPanel = key === 'search' || key === 'categories';
    const already = isPanel ? panel === key : panel === 'list' && actionMode === key;
    setFilters(emptyFilters);
    switchActionMode(null);
    setPanel(already || !isPanel ? 'list' : key);
    if (!already && !isPanel) switchActionMode(key);
  }

  function togglePanel(next) {
    const target = panel === next ? 'list' : next;
    if (target !== 'search') setFilters(emptyFilters);
    setPanel(target);
  }

  // 各幣別換算台幣的匯率,用來比較「當日消費最高」的那一筆
  useEffect(() => {
    const currencies = [...new Set(accounts.map((a) => a.currency || 'TWD'))].filter((c) => c !== 'TWD' && rates[c] == null);
    if (currencies.length === 0) return;
    Promise.all(
      currencies.map((c) => api.getExchangeRate(c, 'TWD').then(({ rate }) => [c, rate]).catch(() => [c, 1]))
    ).then((pairs) => setRates((prev) => ({ ...prev, ...Object.fromEntries(pairs) })));
  }, [accounts]);

  useEffect(() => {
    const fromAcc = accounts.find((a) => a.id === transfer.from);
    const toAcc = accounts.find((a) => a.id === transfer.to);
    if (fromAcc && toAcc && fromAcc.currency !== toAcc.currency) {
      api.getExchangeRate(fromAcc.currency, toAcc.currency)
        .then(({ rate }) => setTransfer((prev) => ({ ...prev, exchangeRate: String(rate) })))
        .catch((err) => console.error('[exchange rate]', err));
    }
  }, [transfer.from, transfer.to, accounts]);

  function switchActionMode(newMode) {
    setActionMode(newMode);
    if (panel === 'categories') setPanel('list');
    setActiveId(null);
    setConfirmDelete(false);
    setForm(emptyForm);
    setTransfer(emptyTransfer);
    setTransferError('');
  }

  function pickTransaction(t) {
    setActiveId(t.id);
    setConfirmDelete(false);
    setForm({
      type: t.type,
      amount: String(t.amount),
      category: t.category || '',
      note: t.note || '',
      account_id: t.account_id || '',
      occurred_at: toLocalDateInput(t.occurred_at),
    });
  }

  // 新增後留在新增(方便連續記帳);編輯/刪除後,桌機版回到新增、手機版回到只看帳務資料
  function resetAfterAction() {
    const next = actionMode === 'add' || isDesktop ? 'add' : null;
    setForm(emptyForm);
    setActionMode(next);
    setActiveId(null);
    setConfirmDelete(false);
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!form.amount) return;
    const occurredAtIso = new Date(`${form.occurred_at}T12:00:00`).toISOString();
    const payload = {
      type: form.type,
      amount: Number(form.amount),
      category: form.category || null,
      note: form.note || null,
      account_id: form.account_id || null,
      occurred_at: occurredAtIso,
    };

    if (actionMode === 'edit' && activeId) {
      await api.updateTransaction(activeId, payload);
    } else {
      await api.createTransaction(payload);
    }
    resetAfterAction();
    load();
  }

  async function handleConfirmDelete() {
    await api.deleteTransaction(activeId);
    resetAfterAction();
    load();
  }

  async function handleTransfer(e) {
    e.preventDefault();
    setTransferError('');
    if (!transfer.from || !transfer.to || !transfer.amount) return;
    if (transfer.from === transfer.to) {
      setTransferError(t('tx_transfer_error_same'));
      return;
    }
    const fromAcc = accounts.find((a) => a.id === transfer.from);
    const toAcc = accounts.find((a) => a.id === transfer.to);
    const needsRate = fromAcc && toAcc && fromAcc.currency !== toAcc.currency;
    if (needsRate && (!transfer.exchangeRate || Number(transfer.exchangeRate) <= 0)) {
      setTransferError(t('tx_transfer_error_rate'));
      return;
    }
    try {
      await api.transferBetweenAccounts({
        from_account_id: transfer.from,
        to_account_id: transfer.to,
        amount: Number(transfer.amount),
        exchange_rate: needsRate ? Number(transfer.exchangeRate) : undefined,
      });
      setTransfer(emptyTransfer);
      load();
    } catch (err) {
      console.error(err);
      setTransferError(t('tx_transfer_error_fail'));
    }
  }

  const grouped = transactions.reduce((acc, t) => {
    const day = toLocalDateInput(t.occurred_at);
    (acc[day] ||= []).push(t);
    return acc;
  }, {});

  // 當日消費最高那一筆(換算台幣比較)的分類顏色;沒有分類顏色時用灰色
  function dayColor(dateKey) {
    const expenses = (grouped[dateKey] || []).filter((tx) => tx.type === 'expense');
    if (expenses.length === 0) return null;
    const toTwd = (tx) => Number(tx.amount) * (rates[accountCurrency(tx.account_id)] ?? 1);
    const top = expenses.reduce((a, b) => (toTwd(b) > toTwd(a) ? b : a));
    return categories.find((c) => c.name === top.category)?.color || '#9CA3AF';
  }

  function accountName(id) {
    return accounts.find((a) => a.id === id)?.name;
  }

  function accountCurrency(id) {
    return accounts.find((a) => a.id === id)?.currency || 'TWD';
  }

  const pickingMode = actionMode === 'edit' && !activeId;
  const relevantCategories = categories.filter((c) => c.type === form.type || c.type === 'general');

  const [filters, setFilters] = useState(emptyFilters);
  const hasFilter = Object.keys(emptyFilters).some((k) => filters[k] !== emptyFilters[k]);

  const currentMonthPrefix = `${month.getFullYear()}-${String(month.getMonth() + 1).padStart(2, '0')}`;
  const monthTransactions = transactions.filter((tx) => toLocalDateInput(tx.occurred_at).slice(0, 7) === currentMonthPrefix);

  // 沒有設定任何查詢條件時顯示本月;有條件時查詢全部紀錄
  const filteredTransactions = !hasFilter
    ? monthTransactions
    : transactions.filter((tx) => {
        const day = toLocalDateInput(tx.occurred_at);
        const amount = Number(tx.amount);
        if (filters.from && day < filters.from) return false;
        if (filters.to && day > filters.to) return false;
        if (filters.type !== 'all' && tx.type !== filters.type) return false;
        if (filters.account && tx.account_id !== filters.account) return false;
        if (filters.category && tx.category !== filters.category) return false;
        if (filters.min !== '' && amount < Number(filters.min)) return false;
        if (filters.max !== '' && amount > Number(filters.max)) return false;
        if (filters.keyword && !(tx.note || '').toLowerCase().includes(filters.keyword.toLowerCase())) return false;
        return true;
      });
  const filteredGrouped = filteredTransactions.reduce((acc, t) => {
    const day = toLocalDateInput(t.occurred_at);
    (acc[day] ||= []).push(t);
    return acc;
  }, {});

  const catColor = (name) => categories.find((c) => c.name === name)?.color || null;

  function renderTxRow(tx) {
    const selectable = actionMode === 'edit';
    const isActive = activeId === tx.id;
    return (
      <div
        key={tx.id}
        onClick={selectable ? () => pickTransaction(tx) : undefined}
        className={`flex items-center justify-between px-4 py-2 text-sm ${selectable ? 'cursor-pointer' : ''} ${isActive ? 'bg-muted' : selectable ? 'hover:bg-muted/50' : ''}`}
      >
        <div className="min-w-0 flex-1 truncate">
          {catColor(tx.category) && (
            <span className="mr-1.5 inline-block h-2 w-2 rounded-full align-middle" style={{ backgroundColor: catColor(tx.category) }} />
          )}
          <span className="text-muted-foreground">
            {[accountName(tx.account_id) || t('tx_unspecified_account'), tx.category].filter(Boolean).join(' · ')}
          </span>
          <span className="text-foreground"> - {tx.note || t('tx_no_note')}</span>
        </div>
        <span className={`font-amount shrink-0 pl-2 flex items-baseline ${tx.type === 'income' ? 'text-green-600' : 'text-foreground'}`}>
          <span className="inline-block w-9 text-left">{accountCurrency(tx.account_id)}</span>
          <span className="inline-block w-16 text-right">{tx.type === 'income' ? '+' : '-'}{Number(tx.amount).toLocaleString()}</span>
        </span>
      </div>
    );
  }

  const searchBlock = (
    <TxSearchBlock
      t={t}
      filters={filters}
      setFilters={setFilters}
      accounts={accounts}
      categories={categories}
      hasFilter={hasFilter}
      count={filteredTransactions.length}
      onClose={panel === 'search' && isDesktop ? () => togglePanel('search') : null}
      hintKey={isDesktop ? 'search_default_hint' : 'cal_search_hint'}
    />
  );

  return (
    <div className="mx-auto max-w-xl px-4 py-6 pb-40 md:max-w-5xl md:px-8 md:py-10" style={{ '--primary': 'var(--module-transactions)', '--ring': 'var(--module-transactions)' }}>
      <div className="page-title-row mb-3 flex items-center justify-between">
        <h1 className="page-title text-lg font-semibold">{t('tx_pageTitle')}</h1>
        <div className={SEG_BAR}>
          <button onClick={() => setView('list')} className={`${segBtn(view === 'list')} px-3 py-1`}>{t('tx_view_list')}</button>
          <button onClick={() => setView('calendar')} className={`${segBtn(view === 'calendar')} px-3 py-1`}>{t('tx_view_calendar')}</button>
        </div>
      </div>
      <LedgerSubNav />

      <div className="md:grid md:grid-cols-[minmax(0,1fr)_380px] md:items-start md:gap-6">
      <div className="md:sticky md:top-6 md:order-2">

      {/* 新增/編輯/轉帳 + 查詢/管理分類 同一個功能列,一次只能選一個(再點一次取消) */}
      {/* 方案沒有記帳功能時:只能查看與查詢 */}
      <ReadOnlyNotice feature="ledger" />
      <div className="mb-3 grid grid-cols-6 gap-1 rounded-lg border border-border bg-card p-1 text-sm shadow-sm">
        {canLedger && (
          <>
            <button onClick={() => selectMobile('add')} className={`col-span-2 px-2 py-1.5 ${segBtn(actionMode === 'add' && panel === 'list')}`}>{t('mode_add')}</button>
            <button onClick={() => selectMobile('edit')} className={`col-span-2 px-2 py-1.5 ${segBtn(actionMode === 'edit' && panel === 'list')}`}>{t('mode_edit')}</button>
            <button onClick={() => selectMobile('transfer')} className={`col-span-2 px-2 py-1.5 ${segBtn(actionMode === 'transfer' && panel === 'list')}`}>{t('mode_transfer')}</button>
          </>
        )}
        {[
          { key: 'search', label: t('search_title') },
          ...(canLedger ? [{ key: 'categories', label: t('tx_manage_categories') }] : []),
        ].map(({ key, label }) => (
          <button key={key} type="button" onClick={() => selectMobile(key)} className={`${canLedger ? 'col-span-3' : 'col-span-6'} px-2 py-1.5 ${segBtn(panel === key)}`}>
            {label}
          </button>
        ))}
      </div>

      {/* 網頁版:查詢條件放在右側功能列下方,左側顯示查詢結果 */}
      {panel === 'search' && isDesktop && <div className="mb-3">{searchBlock}</div>}

      {pickingMode && canLedger && (
        <p className="mb-3 px-1 text-sm text-muted-foreground">{t('tx_pick_edit')}</p>
      )}

      {/* 手機版:沒選功能、或選了查詢/管理分類時,收起表單;點選資料前也不顯示表單 */}
      <Card className={`mb-3 ${!canLedger || pickingMode || !actionMode || panel !== 'list' ? 'hidden' : ''}`}>
        <CardContent className="space-y-2 p-4">
          {actionMode === 'transfer' ? (
            <form onSubmit={handleTransfer} className="space-y-2">
              {transferError && <p className="text-sm text-red-500">{transferError}</p>}
              <Select value={transfer.from || 'none'} onValueChange={(v) => setTransfer({ ...transfer, from: v === 'none' ? '' : v })}>
                <SelectTrigger><SelectValue placeholder={t('tx_transfer_from')} /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">{t('tx_transfer_from')}</SelectItem>
                  {accounts.map((acc) => (
                    <SelectItem key={acc.id} value={acc.id}>{acc.name}({acc.currency || 'TWD'} {Number(acc.balance).toLocaleString()})</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={transfer.to || 'none'} onValueChange={(v) => setTransfer({ ...transfer, to: v === 'none' ? '' : v })}>
                <SelectTrigger><SelectValue placeholder={t('tx_transfer_to')} /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">{t('tx_transfer_to')}</SelectItem>
                  {accounts.map((acc) => (
                    <SelectItem key={acc.id} value={acc.id}>{acc.name}({acc.currency || 'TWD'} {Number(acc.balance).toLocaleString()})</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Input type="number" placeholder={t('tx_transfer_amount')} required value={transfer.amount} onChange={(e) => setTransfer({ ...transfer, amount: e.target.value })} />
              {(() => {
                const fromAcc = accounts.find((a) => a.id === transfer.from);
                const toAcc = accounts.find((a) => a.id === transfer.to);
                const needsRate = fromAcc && toAcc && fromAcc.currency !== toAcc.currency;
                if (!needsRate) return null;
                const converted = transfer.amount && transfer.exchangeRate
                  ? (Number(transfer.amount) * Number(transfer.exchangeRate)).toLocaleString()
                  : null;
                return (
                  <div className="space-y-1">
                    <Input
                      type="number"
                      step="0.0001"
                      placeholder={`${t('tx_exchange_rate')} (1 ${fromAcc.currency} = ? ${toAcc.currency})`}
                      value={transfer.exchangeRate}
                      onChange={(e) => setTransfer({ ...transfer, exchangeRate: e.target.value })}
                    />
                    {converted && (
                      <p className="text-xs text-muted-foreground">
                        {t('tx_exchange_preview')} {toAcc.currency} {converted}
                      </p>
                    )}
                    <p className="text-[11px] text-muted-foreground">{t('tx_exchange_rate_hint')}</p>
                  </div>
                );
              })()}
              <Button type="submit" className="w-full">{t('tx_confirm_transfer')}</Button>
            </form>
          ) : pickingMode ? (
            <p className="py-2 text-center text-sm text-muted-foreground">
              {t('tx_pick_edit')}
            </p>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-2">
              {actionMode === 'edit' && activeId && (
                <p className="text-xs font-medium text-muted-foreground">{t('tx_editing')}</p>
              )}
              <div className="flex gap-2">
                <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v, category: '' })}>
                  <SelectTrigger className="w-28"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="expense">{t('type_expense')}</SelectItem>
                    <SelectItem value="income">{t('type_income')}</SelectItem>
                  </SelectContent>
                </Select>
                <Input type="date" required className="flex-1" value={form.occurred_at} onChange={(e) => setForm({ ...form, occurred_at: e.target.value })} />
              </div>
              <div className="flex flex-wrap gap-2">
                <Select
                  value={form.account_id || 'none'}
                  onValueChange={(v) => setForm({ ...form, account_id: v === 'none' ? '' : v })}
                >
                  <SelectTrigger className="min-w-0 flex-1"><SelectValue placeholder={t('tx_account_placeholder')} /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">{t('tx_no_account')}</SelectItem>
                    {accounts.map((acc) => (
                      <SelectItem key={acc.id} value={acc.id}>{acc.name}({acc.currency || 'TWD'})</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select
                  value={form.category || 'none'}
                  onValueChange={(v) => setForm({ ...form, category: v === 'none' ? '' : v })}
                >
                  <SelectTrigger className="min-w-0 flex-1"><SelectValue placeholder={t('tx_category_placeholder')} /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">{t('tx_no_category')}</SelectItem>
                    {relevantCategories.map((cat) => (
                      <SelectItem key={cat.id} value={cat.name}>{cat.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex gap-2">
                <Input
                  type="text"
                  placeholder={t('tx_note_placeholder')}
                  className="min-w-0 flex-[2]"
                  value={form.note}
                  onChange={(e) => setForm({ ...form, note: e.target.value })}
                />
                <Input type="number" placeholder={`${t('tx_amount')} (${accounts.find((a) => a.id === form.account_id)?.currency || 'TWD'})`} required className="min-w-0 flex-1" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} />
              </div>
              {actionMode === 'edit' && activeId ? (
                confirmDelete ? (
                  <div className="space-y-2 rounded-md border border-border p-2">
                    <p className="text-sm">{t('tx_confirm_delete_title')}</p>
                    <div className="flex gap-2">
                      <Button type="button" variant="destructive" className="flex-1" onClick={handleConfirmDelete}>{t('tx_confirm_delete')}</Button>
                      <Button type="button" variant="outline" className="flex-1" onClick={() => setConfirmDelete(false)}>{t('cancel')}</Button>
                    </div>
                  </div>
                ) : (
                  <div className="flex gap-2">
                    <Button type="submit" className="flex-1">{t('tx_save_edit')}</Button>
                    <Button type="button" variant="outline" onClick={() => setConfirmDelete(true)}>{t('mode_delete')}</Button>
                    <Button type="button" variant="outline" onClick={() => { setActiveId(null); setForm(emptyForm); }}>{t('reselect')}</Button>
                  </div>
                )
              ) : (
                <Button type="submit" className="w-full">{t('tx_add_record')}</Button>
              )}
            </form>
          )}
        </CardContent>
      </Card>
      </div>

      <div className={`md:order-1 ${panel === 'list' && (actionMode === 'add' || actionMode === 'transfer') ? 'hidden md:block' : ''}`}>
      {panel !== 'categories' && !(panel === 'search' && hasFilter) && (
        <MonthSwitcher month={month} onChange={(m) => { setMonth(m); setSelectedDay(null); }} t={t} className={`mb-3 ${panel === 'search' ? 'hidden md:flex' : ''}`} />
      )}
      {panel === 'categories' ? (
        <div>
          <div className="mb-3 flex items-center justify-between">
            <p className="text-sm font-medium">{t('tx_manage_categories')}</p>
            <button type="button" onClick={() => setPanel('list')} className="text-xs text-muted-foreground underline">{t('tx_back_to_list')}</button>
          </div>
          <Categories scope="ledger" embedded onChanged={reloadCategories} />
        </div>
      ) : loading ? (
        <p className="text-sm text-muted-foreground">{t('loading')}</p>
      ) : view === 'list' || panel === 'search' ? (
        <div className="space-y-4">
          {panel === 'search' && !isDesktop && searchBlock}
          {/* 手機版查詢:有設定條件才列出結果 */}
          {!(panel === 'search' && !hasFilter && !isDesktop) && Object.entries(filteredGrouped).map(([day, items]) => (
            <div key={day}>
              <p className="mb-1 text-xs font-medium text-muted-foreground">{day}</p>
              <Card>
                <div className="divide-y divide-border">
                  {items.map(renderTxRow)}
                </div>
              </Card>
            </div>
          ))}
          {filteredTransactions.length === 0 && !(panel === 'search' && !hasFilter && !isDesktop) && <p className="text-sm text-muted-foreground">{t('tx_no_records')}</p>}
        </div>
      ) : (
        <div className="space-y-3">
          <CalendarView
            monthDate={month}
            grouped={grouped}
            weekdays={t('cal_weekdays')}
            dayColor={dayColor}
            selectedDay={selectedDay}
            onSelect={(d) => setSelectedDay((prev) => (prev === d ? null : d))}
          />
          {selectedDay && (
            <div>
              <p className="mb-1 text-xs font-medium text-muted-foreground">{selectedDay}</p>
              {(grouped[selectedDay] || []).length === 0 ? (
                <p className="text-sm text-muted-foreground">{t('tx_no_records')}</p>
              ) : (
                <Card>
                  <div className="divide-y divide-border">{grouped[selectedDay].map(renderTxRow)}</div>
                </Card>
              )}
            </div>
          )}
        </div>
      )}
      </div>
      </div>
    </div>
  );
}

function CalendarView({ grouped, weekdays, dayColor, selectedDay, onSelect, monthDate }) {
  const year = monthDate.getFullYear();
  const month = monthDate.getMonth();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstWeekday = new Date(year, month, 1).getDay();
  const cells = [...Array(firstWeekday).fill(null), ...Array.from({ length: daysInMonth }, (_, i) => i + 1)];

  return (
    <Card>
      <CardContent className="p-4">
        <div className="grid grid-cols-7 gap-1 text-center text-xs text-muted-foreground">
          {weekdays.map((d) => <div key={d}>{d}</div>)}
        </div>
        <div className="mt-2 grid grid-cols-7 gap-1">
          {cells.map((day, idx) => {
            if (!day) return <div key={idx} />;
            const dateKey = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
            const hasEntries = !!grouped[dateKey];
            const color = dayColor(dateKey);
            return (
              <button
                type="button"
                key={idx}
                onClick={() => onSelect(dateKey)}
                className={`flex flex-col items-center rounded-md py-1 text-xs md:py-2 ${selectedDay === dateKey ? 'ring-2 ring-ring' : 'hover:bg-muted/50'}`}
                style={color ? { backgroundColor: `color-mix(in srgb, ${color} 30%, transparent)` } : undefined}
              >
                <span>{day}</span>
                <span className={`mt-0.5 h-1.5 w-1.5 rounded-full ${hasEntries ? 'bg-foreground' : 'bg-transparent'}`} />
              </button>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}

function TxSearchBlock({ t, filters, setFilters, accounts, categories, hasFilter, count, onClose, hintKey = 'search_default_hint' }) {
  const set = (k) => (v) => setFilters((f) => ({ ...f, [k]: v }));
  const label = 'mb-1 block text-xs text-muted-foreground';
  return (
    <Card>
      <CardContent className="space-y-3 p-4">
        <div className="flex items-center justify-between">
          <p className="text-sm font-medium">{t('search_title')}</p>
          <div className="flex gap-3">
            {hasFilter && (
              <button type="button" onClick={() => setFilters(emptyFilters)} className="text-xs text-muted-foreground underline">
                {t('search_clear')}
              </button>
            )}
            {onClose && (
              <button type="button" onClick={onClose} className="text-xs text-muted-foreground underline">
                {t('tx_back_to_list')}
              </button>
            )}
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2 [&>*]:min-w-0">
          <div>
            <span className={label}>{t('search_date_from')}</span>
            <Input type="date" value={filters.from} onChange={(e) => set('from')(e.target.value)} />
          </div>
          <div>
            <span className={label}>{t('search_date_to')}</span>
            <Input type="date" value={filters.to} onChange={(e) => set('to')(e.target.value)} />
          </div>
          <div>
            <span className={label}>{t('search_type')}</span>
            <Select value={filters.type} onValueChange={set('type')}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t('search_all_types')}</SelectItem>
                <SelectItem value="expense">{t('type_expense')}</SelectItem>
                <SelectItem value="income">{t('type_income')}</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <span className={label}>{t('tx_search_by_account')}</span>
            <Select value={filters.account || 'all'} onValueChange={(v) => set('account')(v === 'all' ? '' : v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t('search_all_accounts')}</SelectItem>
                {accounts.map((acc) => (
                  <SelectItem key={acc.id} value={acc.id}>{acc.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="col-span-2">
            <span className={label}>{t('tx_search_by_category')}</span>
            <Select value={filters.category || 'all'} onValueChange={(v) => set('category')(v === 'all' ? '' : v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t('search_all_categories')}</SelectItem>
                {categories.map((cat) => (
                  <SelectItem key={cat.id} value={cat.name}>
                    <span className="inline-flex items-center gap-2">
                      {cat.color && <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: cat.color }} />}
                      {cat.name}
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <span className={label}>{t('search_amount_min')}</span>
            <Input type="number" inputMode="decimal" value={filters.min} onChange={(e) => set('min')(e.target.value)} />
          </div>
          <div>
            <span className={label}>{t('search_amount_max')}</span>
            <Input type="number" inputMode="decimal" value={filters.max} onChange={(e) => set('max')(e.target.value)} />
          </div>
          <div className="col-span-2">
            <span className={label}>{t('search_keyword')}</span>
            <Input type="text" placeholder={t('tx_search_note_placeholder')} value={filters.keyword} onChange={(e) => set('keyword')(e.target.value)} />
          </div>
        </div>
        <p className="text-xs text-muted-foreground">
          {hasFilter ? `${t('search_count_prefix')}${count}${t('search_count_suffix')}` : t(hintKey)}
        </p>
      </CardContent>
    </Card>
  );
}
