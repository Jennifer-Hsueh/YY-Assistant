const supabase = require('../config/supabase');
const images = require('../services/communityImages');
const moderation = require('../services/moderation');
const F = require('../lib/friends');

// 社群:三個板 + 「我的」。
// 可見性一律由後端判斷 —— 私人文章只回傳給作者本人,
// 被檢舉隱藏的文章不出現在板上;回傳資料不含其他人的 user_id / email。
const BOARDS = ['mood', 'finance', 'wish'];
const MOODS = ['sunny', 'cloudy', 'rainy', 'storm', 'rainbow'];
const MOOD_REACTIONS = ['hug', 'cheer', 'understand', 'laugh', 'approve'];
const WISH_STATUSES = ['considering', 'planned', 'done'];
const REPORT_HIDE_THRESHOLD = 3;
const MAX_CONTENT = 2000;
const MAX_TITLE = 80;
const PAGE_SIZE = 30;
const VISIBILITIES = ['private', 'friends', 'public']; // friends:僅好友可見(一定顯示暱稱)

async function isAdmin(userId) {
  const { data } = await supabase.from('yy_users').select('role').eq('id', userId).maybeSingle();
  return data?.role === 'admin';
}

function clean(text, max) {
  if (typeof text !== 'string') return '';
  return text.trim().slice(0, max);
}

// 晴空與雨天的公開文章:只有回應,不開放其他人留言
function commentsAllowed(post, userId) {
  if (post.visibility === 'private') return post.user_id === userId;
  return post.board !== 'mood';
}

// 僅好友可見:作者的好友(沒有互相封鎖)才看得到
// 作者發文時選擇隱藏的好友
const hiddenFor = (post, userId) => Array.isArray(post.hidden_from) && post.hidden_from.includes(userId);

async function canRead(post, userId, admin) {
  if (post.user_id === userId) return true;
  if (!admin && hiddenFor(post, userId)) return false;
  if (post.visibility === 'friends') {
    if (post.hidden && !admin) return false;
    if (admin) return true;
    return (await F.areFriends(userId, post.user_id)) && !(await F.isBlockedEither(userId, post.user_id));
  }
  if (post.visibility !== 'public') return false;
  if (post.hidden && !admin) return false;
  // 作者選擇「不讓好友看到」:作者的好友看不到這篇
  if (post.hide_friends && !admin && (await F.areFriends(userId, post.user_id))) return false;
  return true;
}

async function decorate(posts, userId) {
  if (posts.length === 0) return [];
  const ids = posts.map((p) => p.id);
  const authorIds = [...new Set(posts.map((p) => p.user_id))];
  const [{ data: reactions }, { data: comments }, { data: authors }] = await Promise.all([
    supabase.from('yy_post_reactions').select('post_id, user_id, type').in('post_id', ids),
    supabase.from('yy_post_comments').select('post_id').in('post_id', ids),
    supabase.from('yy_users').select('id, username, email').in('id', authorIds),
  ]);
  return images.signPosts(posts.map((p) => {
    const mine = p.user_id === userId;
    const author = (authors || []).find((a) => a.id === p.user_id);
    const counts = {};
    let myReaction = null;
    for (const r of reactions || []) {
      if (r.post_id !== p.id) continue;
      counts[r.type] = (counts[r.type] || 0) + 1;
      if (r.user_id === userId) myReaction = r.type;
    }
    const { user_id, hidden_from, ...rest } = p;
    return {
      ...rest,
      // 隱藏了哪些好友只給作者自己看
      ...(mine ? { hidden_from: hidden_from || [] } : {}),
      is_mine: mine,
      author_name: p.anonymous && !mine ? null : (author?.username || author?.email?.split('@')[0] || ''),
      reactions: counts,
      my_reaction: myReaction,
      comment_count: (comments || []).filter((c) => c.post_id === p.id).length,
    };
  }));
}

async function fetchPost(id) {
  const { data, error } = await supabase.from('yy_posts').select('*').eq('id', id).maybeSingle();
  if (error) throw error;
  return data;
}

// GET /community/posts?board=mood|finance|wish|mine&visibility=private|friends|public&scope=friends&before=ISO
async function listPosts(req, res) {
  try {
    const { board, visibility, before, scope } = req.query;
    let q = supabase.from('yy_posts').select('*').order('created_at', { ascending: false }).limit(PAGE_SIZE);
    if (board === 'mine') {
      q = q.eq('user_id', req.user.id);
      if (VISIBILITIES.includes(visibility)) q = q.eq('visibility', visibility);
    } else if (board === 'friend') {
      // 某位好友的文章:僅好友可見+具名公開;不含匿名、被隱藏的
      const fid = String(req.query.user_id || '');
      if (!fid || !(await F.areFriends(req.user.id, fid)) || (await F.isBlockedEither(req.user.id, fid))) return res.status(404).json({ error: 'Not found' });
      q = q.eq('user_id', fid).eq('hidden', false).eq('hide_friends', false)
        .or('visibility.eq.friends,and(visibility.eq.public,anonymous.eq.false)');
    } else if (BOARDS.includes(board) && scope === 'friends') {
      // 好友篩選:好友的公開(具名)文章+僅好友可見的文章;不含作者設定「不讓好友看到」的文章
      const ids = await F.friendIds(req.user.id);
      if (!ids.length) return res.json({ posts: [] });
      q = q.eq('board', board).eq('hidden', false).eq('hide_friends', false).in('user_id', ids)
        .or('visibility.eq.friends,and(visibility.eq.public,anonymous.eq.false)');
    } else if (BOARDS.includes(board)) {
      q = q.eq('board', board).eq('visibility', 'public').eq('hidden', false);
    } else {
      return res.status(400).json({ error: 'Invalid board' });
    }
    if (before) q = q.lt('created_at', before);
    const { data, error } = await q;
    if (error) throw error;
    let rows = (data || []).filter((p) => p.user_id === req.user.id || !hiddenFor(p, req.user.id));
    // 公開板:作者設定「不讓好友看到」的文章,不給作者的好友看
    if (BOARDS.includes(board) && scope !== 'friends' && rows.some((p) => p.hide_friends && p.user_id !== req.user.id)) {
      const friends = new Set(await F.friendIds(req.user.id));
      rows = rows.filter((p) => !(p.hide_friends && friends.has(p.user_id)));
    }
    return res.json({ posts: await decorate(rows, req.user.id), has_more: (data || []).length === PAGE_SIZE });
  } catch (err) {
    console.error('[communityController.listPosts]', err);
    return res.status(500).json({ error: 'Failed to fetch posts' });
  }
}

// GET /community/stats — 「我的」統計
async function myStats(req, res) {
  try {
    const { data: posts, error } = await supabase.from('yy_posts').select('id, visibility').eq('user_id', req.user.id);
    if (error) throw error;
    const ids = posts.map((p) => p.id);
    let received = 0;
    if (ids.length) {
      const { count } = await supabase
        .from('yy_post_reactions')
        .select('post_id', { count: 'exact', head: true })
        .in('post_id', ids)
        .neq('user_id', req.user.id);
      received = count || 0;
    }
    return res.json({
      stats: {
        private: posts.filter((p) => p.visibility === 'private').length,
        public: posts.filter((p) => p.visibility === 'public').length,
        friends: posts.filter((p) => p.visibility === 'friends').length,
        reactions_received: received,
      },
    });
  } catch (err) {
    console.error('[communityController.myStats]', err);
    return res.status(500).json({ error: 'Failed to fetch stats' });
  }
}

// 隱藏名單:只能選自己的好友
async function cleanHidden(userId, list) {
  if (!Array.isArray(list) || !list.length) return [];
  const friends = new Set(await F.friendIds(userId));
  return [...new Set(list.map(String))].filter((id) => friends.has(id)).slice(0, 200);
}

async function createPost(req, res) {
  try {
    const { board, visibility, anonymous, mood, title } = req.body;
    const content = clean(req.body.content, MAX_CONTENT);
    if (!BOARDS.includes(board)) return res.status(400).json({ error: 'Invalid board' });
    if (!content) return res.status(400).json({ error: 'content is required' });
    if (board === 'mood' && mood != null && !MOODS.includes(mood)) return res.status(400).json({ error: 'Invalid mood' });
    const keys = images.validKeys(req.user.id, req.body.images);
    if (keys === null) return res.status(400).json({ error: 'Invalid images' });
    // 社群暫停期間只能發表僅自己可見的文章
    const vis = VISIBILITIES.includes(visibility) ? visibility : 'private';
    if (vis !== 'private') {
      const until = await moderation.suspendedUntil(req.user.id);
      if (until) return moderation.suspendedError(res, until);
    }

    const { data, error } = await supabase
      .from('yy_posts')
      .insert({
        user_id: req.user.id,
        board,
        visibility: vis,
        anonymous: vis === 'public' && !!anonymous,
        hide_friends: vis === 'public' && !!req.body.hide_friends,
        hidden_from: vis === 'private' ? [] : await cleanHidden(req.user.id, req.body.hidden_from),
        mood: board === 'mood' ? mood || null : null,
        title: board === 'mood' ? null : clean(title, MAX_TITLE) || null,
        content,
        images: keys || [],
      })
      .select()
      .single();
    if (error) throw error;
    const [post] = await decorate([data], req.user.id);
    return res.status(201).json({ post });
  } catch (err) {
    console.error('[communityController.createPost]', err);
    return res.status(500).json({ error: 'Failed to create post' });
  }
}

// 作者可改內容與公開範圍(公開 → 僅自己 = 從板上收回)
async function updatePost(req, res) {
  try {
    const post = await fetchPost(req.params.id);
    if (!post || post.user_id !== req.user.id) return res.status(404).json({ error: 'Post not found' });
    const updates = { updated_at: new Date().toISOString() };
    const { visibility, anonymous, mood, title, content } = req.body;
    if (visibility !== undefined) updates.visibility = VISIBILITIES.includes(visibility) ? visibility : 'private';
    if ((updates.visibility || post.visibility) !== 'private') {
      const until = await moderation.suspendedUntil(req.user.id);
      if (until) return moderation.suspendedError(res, until);
    }
    if (anonymous !== undefined) updates.anonymous = !!anonymous;
    // 僅好友可見一定具名
    if ((updates.visibility || post.visibility) === 'friends') updates.anonymous = false;
    if (req.body.hide_friends !== undefined) updates.hide_friends = !!req.body.hide_friends;
    if (req.body.hidden_from !== undefined) updates.hidden_from = await cleanHidden(req.user.id, req.body.hidden_from);
    // 「隱藏全部好友」只適用公開文章;僅自己可見不需要隱藏名單
    if ((updates.visibility || post.visibility) !== 'public') updates.hide_friends = false;
    if ((updates.visibility || post.visibility) === 'private') updates.hidden_from = [];
    if (mood !== undefined && post.board === 'mood') {
      if (mood !== null && !MOODS.includes(mood)) return res.status(400).json({ error: 'Invalid mood' });
      updates.mood = mood;
    }
    if (title !== undefined && post.board !== 'mood') updates.title = clean(title, MAX_TITLE) || null;
    if (content !== undefined) {
      const c = clean(content, MAX_CONTENT);
      if (!c) return res.status(400).json({ error: 'content is required' });
      updates.content = c;
    }
    const keys = images.validKeys(req.user.id, req.body.images);
    if (keys === null) return res.status(400).json({ error: 'Invalid images' });
    const oldKeys = Array.isArray(post.images) ? post.images : [];
    if (keys !== undefined) updates.images = keys;
    // 內容、標題或照片有變才算「已編輯」(只改公開範圍不算)
    const edited = (updates.content !== undefined && updates.content !== post.content)
      || (updates.title !== undefined && updates.title !== post.title)
      || (keys !== undefined && JSON.stringify(keys) !== JSON.stringify(oldKeys));
    if (edited) updates.edited_at = updates.updated_at;
    const { data, error } = await supabase.from('yy_posts').update(updates).eq('id', post.id).select().single();
    if (error) throw error;
    if (keys !== undefined) await images.removeImages(oldKeys.filter((k) => !keys.includes(k)));
    const [decorated] = await decorate([data], req.user.id);
    return res.json({ post: decorated });
  } catch (err) {
    console.error('[communityController.updatePost]', err);
    return res.status(500).json({ error: 'Failed to update post' });
  }
}

async function deletePost(req, res) {
  try {
    const post = await fetchPost(req.params.id);
    if (!post) return res.status(404).json({ error: 'Post not found' });
    if (post.user_id !== req.user.id && !(await isAdmin(req.user.id))) {
      return res.status(404).json({ error: 'Post not found' });
    }
    const { error } = await supabase.from('yy_posts').delete().eq('id', post.id);
    if (error) throw error;
    await images.removeImages(post.images);
    return res.json({ message: 'Post deleted' });
  } catch (err) {
    console.error('[communityController.deletePost]', err);
    return res.status(500).json({ error: 'Failed to delete post' });
  }
}

async function listComments(req, res) {
  try {
    const post = await fetchPost(req.params.id);
    const admin = post && post.user_id !== req.user.id ? await isAdmin(req.user.id) : false;
    if (!post || !(await canRead(post, req.user.id, admin))) return res.status(404).json({ error: 'Post not found' });
    const { data, error } = await supabase
      .from('yy_post_comments')
      .select('id, user_id, content, created_at')
      .eq('post_id', post.id)
      .order('created_at', { ascending: true });
    if (error) throw error;
    const authorIds = [...new Set(data.map((c) => c.user_id))];
    const { data: authors } = authorIds.length
      ? await supabase.from('yy_users').select('id, username, email').in('id', authorIds)
      : { data: [] };
    const comments = data.map(({ user_id, ...c }) => {
      const a = (authors || []).find((x) => x.id === user_id);
      return {
        ...c,
        is_mine: user_id === req.user.id,
        is_post_author: user_id === post.user_id,
        // 匿名文章的作者在自己的文章下留言,也維持匿名
        author_name: user_id === post.user_id && post.anonymous && user_id !== req.user.id
          ? null
          : (a?.username || a?.email?.split('@')[0] || ''),
      };
    });
    return res.json({ comments });
  } catch (err) {
    console.error('[communityController.listComments]', err);
    return res.status(500).json({ error: 'Failed to fetch comments' });
  }
}

async function createComment(req, res) {
  try {
    const post = await fetchPost(req.params.id);
    if (!post || !(await canRead(post, req.user.id, false)) || post.hidden) return res.status(404).json({ error: 'Post not found' });
    if (!commentsAllowed(post, req.user.id)) return res.status(403).json({ error: 'Comments are not allowed on this post' });
    if (post.user_id !== req.user.id) {
      const until = await moderation.suspendedUntil(req.user.id);
      if (until) return moderation.suspendedError(res, until);
    }
    const content = clean(req.body.content, MAX_CONTENT);
    if (!content) return res.status(400).json({ error: 'content is required' });
    const { data, error } = await supabase
      .from('yy_post_comments')
      .insert({ post_id: post.id, user_id: req.user.id, content })
      .select('id, content, created_at')
      .single();
    if (error) throw error;
    const { data: me } = await supabase.from('yy_users').select('username, email').eq('id', req.user.id).maybeSingle();
    return res.status(201).json({
      comment: {
        ...data,
        is_mine: true,
        is_post_author: post.user_id === req.user.id,
        author_name: me?.username || me?.email?.split('@')[0] || '',
      },
    });
  } catch (err) {
    console.error('[communityController.createComment]', err);
    return res.status(500).json({ error: 'Failed to create comment' });
  }
}

async function deleteComment(req, res) {
  try {
    const { data: comment, error: fErr } = await supabase
      .from('yy_post_comments').select('id, user_id').eq('id', req.params.id).maybeSingle();
    if (fErr) throw fErr;
    if (!comment || (comment.user_id !== req.user.id && !(await isAdmin(req.user.id)))) {
      return res.status(404).json({ error: 'Comment not found' });
    }
    const { error } = await supabase.from('yy_post_comments').delete().eq('id', comment.id);
    if (error) throw error;
    return res.json({ message: 'Comment deleted' });
  } catch (err) {
    console.error('[communityController.deleteComment]', err);
    return res.status(500).json({ error: 'Failed to delete comment' });
  }
}

// 每人每篇一種回應:同一種再點一次 = 取消;點不同的 = 換成新的
async function react(req, res) {
  try {
    const post = await fetchPost(req.params.id);
    if (!post || post.visibility === 'private' || post.hidden || !(await canRead(post, req.user.id, false))) return res.status(404).json({ error: 'Post not found' });
    const { type } = req.body;
    const allowed = post.board === 'mood' ? MOOD_REACTIONS : ['like'];
    if (!allowed.includes(type)) return res.status(400).json({ error: 'Invalid reaction' });
    const until = await moderation.suspendedUntil(req.user.id);
    if (until) return moderation.suspendedError(res, until);

    const { data: existing } = await supabase
      .from('yy_post_reactions').select('type').eq('post_id', post.id).eq('user_id', req.user.id).maybeSingle();
    if (existing?.type === type) {
      await supabase.from('yy_post_reactions').delete().eq('post_id', post.id).eq('user_id', req.user.id);
    } else {
      const { error } = await supabase
        .from('yy_post_reactions')
        .upsert({ post_id: post.id, user_id: req.user.id, type }, { onConflict: 'post_id,user_id' });
      if (error) throw error;
    }
    const [decorated] = await decorate([post], req.user.id);
    return res.json({ post: decorated });
  } catch (err) {
    console.error('[communityController.react]', err);
    return res.status(500).json({ error: 'Failed to react' });
  }
}

async function report(req, res) {
  try {
    const post = await fetchPost(req.params.id);
    if (!post || post.visibility === 'private' || post.user_id === req.user.id || !(await canRead(post, req.user.id, false))) return res.status(404).json({ error: 'Post not found' });
    const { error } = await supabase
      .from('yy_post_reports')
      .upsert({ post_id: post.id, user_id: req.user.id, reason: clean(req.body.reason, 200) || null }, { onConflict: 'post_id,user_id' });
    if (error) throw error;
    const { count } = await supabase
      .from('yy_post_reports').select('id', { count: 'exact', head: true }).eq('post_id', post.id);
    if ((count || 0) >= REPORT_HIDE_THRESHOLD && !post.hidden) {
      await supabase.from('yy_posts').update({ hidden: true }).eq('id', post.id);
    }
    return res.json({ message: 'Reported' });
  } catch (err) {
    console.error('[communityController.report]', err);
    return res.status(500).json({ error: 'Failed to report' });
  }
}

// 小編許願池:只有管理員能標狀態
async function setWishStatus(req, res) {
  try {
    if (!(await isAdmin(req.user.id))) return res.status(403).json({ error: 'Admin only' });
    const post = await fetchPost(req.params.id);
    if (!post || post.board !== 'wish') return res.status(404).json({ error: 'Post not found' });
    const { wish_status } = req.body;
    if (wish_status !== null && !WISH_STATUSES.includes(wish_status)) return res.status(400).json({ error: 'Invalid status' });
    const { data, error } = await supabase.from('yy_posts').update({ wish_status }).eq('id', post.id).select().single();
    if (error) throw error;
    const [decorated] = await decorate([data], req.user.id);
    return res.json({ post: decorated });
  } catch (err) {
    console.error('[communityController.setWishStatus]', err);
    return res.status(500).json({ error: 'Failed to update status' });
  }
}

// 上傳一張照片(前端已壓縮並附縮圖),回傳之後發文要帶的 key
async function uploadImage(req, res) {
  try {
    const key = await images.uploadImage(req.user.id, req.body?.image, req.body?.thumb);
    const [signed] = await images.signPosts([{ images: [key] }]);
    return res.status(201).json({ image: signed.images[0] || { key } });
  } catch (err) {
    if (err.status) return res.status(err.status).json({ error: err.message });
    console.error('[communityController.uploadImage]', err);
    return res.status(500).json({ error: 'Failed to upload image' });
  }
}

module.exports = {
  uploadImage,
  listPosts, myStats, createPost, updatePost, deletePost,
  listComments, createComment, deleteComment, react, report, setWishStatus,
};
