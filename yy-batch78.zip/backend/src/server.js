require('dotenv').config();
// 錯誤通知(Sentry)要最先載入
require('./instrument');
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');

const authRoutes = require('./routes/authRoutes');
const transactionRoutes = require('./routes/transactionRoutes');
const accountRoutes = require('./routes/accountRoutes');
const categoryRoutes = require('./routes/categoryRoutes');
const eventRoutes = require('./routes/eventRoutes');
const recurringRoutes = require('./routes/recurringRoutes');
const pushRoutes = require('./routes/pushRoutes');
const { startRecurringScheduler, runDailyRecurringScan } = require('./jobs/recurringScheduler');
const { startEventReminders, runEventReminders } = require('./jobs/eventReminder');
const profileRoutes = require('./routes/profileRoutes');
const bugReportRoutes = require('./routes/bugReportRoutes');
const app = express();
const announcementRoutes = require('./routes/announcementRoutes');
const exchangeRateRoutes = require('./routes/exchangeRateRoutes');
const communityRoutes = require('./routes/communityRoutes');
const budgetRoutes = require('./routes/budgetRoutes');
const moodRoutes = require('./routes/moodRoutes');
const dataRoutes = require('./routes/dataRoutes');
const noteRoutes = require('./routes/noteRoutes');
const adminRoutes = require('./routes/adminRoutes');
const { runBackup, notify } = require('./services/backupService');
const { runPlanNotices } = require('./services/planNoticeService');
const { checkSchema, schemaStatus } = require('./lib/schemaCheck');
// Render 前面有一層代理,讓 req.ip 取得使用者真正的 IP(次數限制會用到)
app.set('trust proxy', 1);
// 安全標頭(API 只回 JSON;允許其他網域讀取回應,前端與後台在不同網址)
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
// CORS:只允許自己的前端、後台、APP 與本機開發呼叫;沒有 Origin 的請求(cron-job.org、伺服器對伺服器)照常
const ALLOWED_ORIGINS = new Set([
  'https://yy-assistant-front.onrender.com',
  process.env.APP_URL,
  process.env.ADMIN_URL,
  ...(process.env.CORS_ORIGINS || '').split(','),
  'capacitor://localhost', 'https://localhost', 'http://localhost',
  'http://localhost:5173', 'http://localhost:5174', 'http://localhost:4173',
].map((o) => (o || '').trim().replace(/\/$/, '')).filter(Boolean));
const OWN_RENDER = /^https:\/\/yy-assistant[a-z0-9-]*\.onrender\.com$/;
app.use(cors({
  origin(origin, cb) {
    if (!origin || ALLOWED_ORIGINS.has(origin) || OWN_RENDER.test(origin)) return cb(null, true);
    console.warn(`[cors] blocked origin ${origin}`);
    return cb(null, false);
  },
}));
// 匯入備份檔可能比較大,這個路徑放寬上限(要放在全域 json 解析之前)
app.use('/api/data', express.json({ limit: '15mb' }));
// 社群照片以 base64 上傳(前端已壓縮,單張約 0.2–1.5MB)
app.use('/api/community', express.json({ limit: '4mb' }));
app.use('/api/payment-reports', express.json({ limit: '3mb' }));
app.use(express.json({ limit: '2mb' }));
// 英文介面:錯誤訊息換成英文(前端送 X-Lang: en)
app.use(require('./lib/i18n').langMiddleware);

app.get('/health', (req, res) => {
  const sc = schemaStatus();
  // schema: ok / missing(缺欄位,詳細看 Logs)/ checking
  res.json({ status: 'ok', time: new Date().toISOString(), schema: sc.ok === null ? 'checking' : sc.ok ? 'ok' : 'missing' });
});

// Called daily by cron-job.org so recurring items run even if the 08:00 tick
// was missed while the instance was asleep. Protected by CRON_SECRET.
app.get('/cron/recurring', async (req, res) => {
  if (!process.env.CRON_SECRET || req.query.key !== process.env.CRON_SECRET) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  try {
    const result = await runDailyRecurringScan();
    // 方案到期通知也在這裡每天跑一次(失敗不影響循環記帳的結果)
    let notices;
    try {
      notices = await runPlanNotices();
    } catch (err) {
      console.error('[cron/planNotices]', err);
      notices = { error: true };
    }
    return res.json({ status: 'ok', ...result, notices });
  } catch (err) {
    console.error('[cron/recurring]', err);
    return res.status(500).json({ error: 'Scan failed' });
  }
});

// 行程提醒:建議在 cron-job.org 設定每 5 分鐘呼叫一次(同時讓伺服器保持清醒)
app.get('/cron/event-reminders', async (req, res) => {
  if (!process.env.CRON_SECRET || req.query.key !== process.env.CRON_SECRET) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  try {
    const result = await runEventReminders();
    return res.json({ status: 'ok', ...result });
  } catch (err) {
    console.error('[cron/event-reminders]', err);
    return res.status(500).json({ error: 'Reminder run failed' });
  }
});

// 每週自動備份:建議在 cron-job.org 設定每週一次(例如週日 03:10 台灣時間)
app.get('/cron/backup', async (req, res) => {
  if (!process.env.CRON_SECRET || req.query.key !== process.env.CRON_SECRET) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  try {
    const result = await runBackup();
    await notify(true, result);
    const { counts, ...summary } = result;
    return res.json({ status: 'ok', ...summary });
  } catch (err) {
    console.error('[cron/backup]', err);
    await notify(false, err.message);
    return res.status(500).json({ error: 'Backup failed' });
  }
});

// 公開:測試名額(入口頁、註冊頁顯示)
app.get('/api/public/beta', async (req, res) => {
  try {
    const { active, limit, used, remaining, full, ends_at } = await require('./lib/beta').betaStatus();
    res.json({ beta: { active, limit, used, remaining, full, ends_at } });
  } catch (err) {
    console.error('[public.beta]', err);
    res.status(500).json({ error: 'Failed to load beta status' });
  }
});
app.use('/api/auth', authRoutes);
app.use('/api/transactions', transactionRoutes);
app.use('/api/accounts', accountRoutes);
app.use('/api/categories', categoryRoutes);
app.use('/api/events', eventRoutes);
app.use('/api/recurring-items', recurringRoutes);
app.use('/api/push-subscriptions', pushRoutes);
app.use('/api/announcements', announcementRoutes);
app.use('/api/profile', profileRoutes);
app.use('/api/bug-reports', bugReportRoutes);
app.use('/api/exchange-rate', exchangeRateRoutes);
app.use('/api/community', communityRoutes);
app.use('/api/budgets', budgetRoutes);
app.use('/api/moods', moodRoutes);
app.use('/api/data', dataRoutes);
app.use('/api/notes', noteRoutes);
app.use('/api/friends', require('./routes/friendRoutes'));
app.use('/api/ledgers', require('./routes/ledgerRoutes'));
app.use('/api/anniversaries', require('./routes/anniversaryRoutes'));
app.use('/api/slips', require('./routes/slipRoutes'));
app.use('/api/payment-reports', require('./routes/paymentReportRoutes'));
app.use('/api/admin', adminRoutes);

// 404 fallback
app.use((req, res) => res.status(404).json({ error: 'Not found' }));

// Central error handler (routes should still try/catch and respond themselves;
// this is a safety net for anything that slips through)
app.use((err, req, res, next) => {
  console.error('[unhandled error]', err);
  res.status(500).json({ error: 'Internal server error' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Backend listening on port ${PORT}`);
  checkSchema().catch((err) => console.error('[schemaCheck] failed', err));
  startRecurringScheduler();
  startEventReminders();
});
